def solve(:
